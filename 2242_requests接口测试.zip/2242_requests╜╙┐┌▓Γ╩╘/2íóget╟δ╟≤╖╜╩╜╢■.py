# 1、导包、
import requests
# 2、编写测试脚本，get请求参数在请求正文(使用字典格式进行传递)
qq_url = "http://1.15.24.75:8080/pinter/com/getSku"
zxc = {
    "id":"1"
}
# 3、发送请求
aa = requests.get(url = qq_url,params=zxc)
# 4、查看请求结果：通过.text的方式进行查看
print(aa.text)


