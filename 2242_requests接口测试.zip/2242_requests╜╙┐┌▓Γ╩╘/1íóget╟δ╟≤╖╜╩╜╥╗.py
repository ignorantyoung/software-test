"""
requests：python用于进行接口请求/测试的第三方库
接口包含什么内容：
    请求地址(必要)、请求头(Content-Type定义请求格式，非必要)、请求正文(格式，非必要)
    响应行、响应头、响应正文
# 1、导包
# 2、编写测试脚本
# 3、发送请求
# 4、查看请求结果
"""""
# requests接口测试步骤
# 1、导包
import requests
# 2、编写测试脚本：发送请求，只有请求地址是必须要有的，其他根据实际情况来定
# get请求参数在请求地址中
aa = "http://v.juhe.cn/dream/category?key=9969069baf50723d4672abeb23b56516&fid=0"
# 3、发送请求
bb = requests.get(url=aa)
# 4、查看响应结果：通过.text的方式进行查看
print(bb.text)



