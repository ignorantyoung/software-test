
from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep
driver = webdriver.Chrome()

driver.get('http://106.52.182.140/fanwe/member.php?ctl=uc_consignee')
# 添加cookies
'''使用方法：  driver.add_cookie({'name' : 'name值', 'value' : '对应的value值'})'''
driver.add_cookie({'name' : 'PHPSESSID', 'value' : 'if9onk6ru40hhpr48riuisv823'})

# 再次进行访问 添加地址
driver.get('http://106.52.182.140/fanwe/member.php?ctl=uc_consignee')
sleep(1)
driver.find_element(By.CSS_SELECTOR,"#add_consignee > div > span").click()
sleep(1)
driver.find_element(By.XPATH,'//*[@id="add_consignee"]/table/tbody/tr/td[2]/div[2]/form/div[5]/div').click()
sleep(2)
# 在测试过程中需要保存测试记录，或者出现问题是保存截图时使用
# 保存截图：写明路径\自定义截图名.png   如果使用jpg会有警告,并不是报错
driver.save_screenshot('.\\abc.png')  # 注意路径一定是存在的，使用双反斜杠
driver.quit()
