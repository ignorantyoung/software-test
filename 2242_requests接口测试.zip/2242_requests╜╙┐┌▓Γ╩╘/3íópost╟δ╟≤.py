# 1、导包
import requests
# 2、编写测试脚本：请求url、请求正文参数（字典格式）
# post请求，请求地址的参数 跟 请求正文的参数不是同一回事
fw_url = "http://106.52.182.140/fanwe/index.php?ctl=user&act=dologin&fhash=FsIbRojthGwgtekQVcJmfqgznRZQNfsSjzcHEInjiByLLVOwOl"
fw_data = {
"email":"test02",
"user_pwd":"UEJHb3BWWmhuVEZ0VEVtbE1McnlRUVZGeExnYXFPdk1FaW1hWXBMcE9kS01pRVFyclElMjV1NjVCOSUyNXU3RUY0cXdlMTIzNDU2JTI1dThGNkYlMjV1NEVGNg==",
"auto_login":"0",
"ajax":"1"
}
# 3、发送请求
fw = requests.post(url=fw_url,data=fw_data)
# 4、查看请求结果：响应正文是JSON格式，可以使用.json()查看
print(fw.text)
print(fw.json())