# 1、导包
import requests
# 2、编写测试脚本：url+请求正文
dz_url = "http://106.52.182.140/fanwe/member.php?ctl=uc_consignee&act=save_consignee&fhash=FsIbRojthGwgtekQVcJmfqgznRZQNfsSjzcHEInjiByLLVOwOl "
dZ_data = {
"consignee":"张三",
"address":"北京路11号",
"mobile":"13512341234",
"ajax":"1",
"id":""
}
# 需要身份信息/鉴权：cookies
# 使用字典格式存储cookies，进行传递
# 通过抓包中的等号 =，左右进行划分
# PHPSESSID=if9onk6ru40hhpr48riuisv823
aa = {
"PHPSESSID":"if9onk6ru40hhpr48riuisv823"
}
# 3、发送请求
dz = requests.post(url=dz_url,data=dZ_data,cookies=aa)
# 4、查看请求结果
print(dz.json())
