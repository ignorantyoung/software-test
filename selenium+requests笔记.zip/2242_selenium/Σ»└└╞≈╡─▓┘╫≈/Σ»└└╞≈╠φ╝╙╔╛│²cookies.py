
from selenium import webdriver
from time import sleep
driver = webdriver.Chrome()

driver.get('http://106.52.182.140/fanwe/member.php?ctl=uc_consignee')
# 添加cookies
'''使用方法：  driver.add_cookie({'name' : 'name值', 'value' : '对应的value值'})'''
driver.add_cookie({'name' : 'PHPSESSID', 'value' : 'if9onk6ru40hhpr48riuisv823'})

# 再次进行访问 添加地址
driver.get('http://106.52.182.140/fanwe/member.php?ctl=uc_consignee')
sleep(2)
# driver.delete_cookie('PHPSESSID')   # 需要写明cookies名称
driver.delete_all_cookies()   # 直接删除所有cookie，不用管cookie名称

# 访问 我要借款，删了cookies后是无法访问，跳转登陆
driver.get("http://106.52.182.140/fanwe/index.php?ctl=borrow&act=stepone&typeid=1")
sleep(2)
driver.quit()
