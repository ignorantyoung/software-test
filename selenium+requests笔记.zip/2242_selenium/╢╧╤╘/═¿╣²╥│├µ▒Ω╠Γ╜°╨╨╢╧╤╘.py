# 1、导包
from selenium import webdriver      # 导入如浏览器驱动包
from selenium.webdriver.common.by import By   # 导入元素定位方法包
from time import sleep   # 导入睡眠时间包
# 2、选择浏览器驱动
driver = webdriver.Chrome()
# 3、使用驱动访问网址
driver.get("http://106.52.182.140/fanwe/m.php?m=Public&a=login&")
driver.maximize_window()        # 浏览器窗口最大化
# 4、进行元素定位并操作
driver.find_element(By.NAME,"adm_name").send_keys("admin")  #定位并输入账号
driver.find_element(By.NAME,"adm_password").send_keys("admin")  #定位并输入密码
driver.find_element(By.NAME,"adm_verify").send_keys('1234')  # 定位并输入验证
driver.find_element(By.ID,'login_btn').click()   # 点击登陆按钮
sleep(5)
# 通过页面标题断言，一定是执行用例之后，标题有发生变化才可以使用
# 管理员登陆   管理平台

# 获取执行用例后的  页面标题
login_title = driver.title
print("标题内容为：",login_title)

# 断言：通过文本内容进行断言。断言成功，没有任何提示；断言失败，才会有提示
# 公式： assert 预期结果 对比(等于==，存在in，不存在not in) 实际结果 ,否则提示自定义的断言失败提示语
# "管理平台"  in  "p2p信贷 - 管理平台"
assert "管理平台" in login_title,"这就是登陆失败了"

# 执行之前的标题 "登陆"  not in  "p2p信贷 - 管理平台"
assert "登陆" not in login_title,"登陆失败"

